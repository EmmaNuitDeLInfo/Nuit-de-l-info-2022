import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router} from '@angular/router';

export interface DialogData {
  firstName: string;
  city: string;
  favorite: string;
}

@Component({
  selector: 'app-input-form',
  templateUrl: './input-form.component.html',
  styleUrls: ['./input-form.component.css']
})
export class InputFormComponent implements OnInit {
  city: string = "";
  firstname: string="";
  favorite: string = "";
  incorrectFN: boolean = false;
  incorrectC: boolean = false;
  incorrectF: boolean = false;

  constructor(private router: Router,public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  cityFormControl = new FormControl('', [Validators.required]);
  firstnameFormControl = new FormControl('', [Validators.required ]);
  favoriteFormControl = new FormControl('', [Validators.required, Validators.pattern("([1-9]?[0-9])|100") ]);

  incorrectFirstName() : void{
    if(this.firstnameFormControl.invalid) this.incorrectFN = true;
    else this.incorrectFN = false;
  }
  incorrectCity() : void{
    if(this.cityFormControl.invalid) this.incorrectC = true;
    else this.incorrectC = false;
  }
  incorrectFavorite() : void{
    if(this.favoriteFormControl.invalid) this.incorrectF = true;
    else this.incorrectF = false;
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(CongratulationComponent, {
      width: '500px',
      data: {firstName: this.firstname, city: this.city, favorite: this.favorite},
    });

    dialogRef.afterClosed().subscribe(result => {
      
    });
  }

  submit(){
    this.incorrectFirstName()
    this.incorrectCity()
    this.incorrectFavorite()
    if(this.favoriteFormControl.valid && this.firstnameFormControl.valid && this.cityFormControl.valid){
      this.openDialog()
    }

  }
}

@Component({
  selector: 'congratulation',
  templateUrl: 'congratulation.component.html',
})
export class CongratulationComponent {
  constructor(
    public dialogRef: MatDialogRef<CongratulationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
